# Legacy material (not used in the revised paper)

Kept only so that the history of the revision can be inspected. Nothing in this folder is read by the current
scripts, and none of these numbers appear in the revised manuscript.

- `scripts/make_figures.py`, `results/figures_v15/`, `results/summary_v15.csv`, `results/composite_v15.csv`:
  figures and summary of the first submission (simulator v15–v17). They include the throughput metric that the
  revision removed and were produced before the corrections described in Section 8.3 of the paper.
- `scripts/run_competitors.py`, `scripts/run_infiltration.py`, `results/competitors.csv`, `results/infiltration*.csv`,
  `results/per_seed_*.csv`: first-submission comparison runs.
- `results/*_10seeds.csv`: intermediate 10-seed runs, superseded by the 30-seed runs in `results/`.
- `results/v20_pre_audit/`: complete outputs of v20, before the v21 code audit (twin forecast one hour ahead of the
  physics, DPoS quorum of five). Every v21 result was recomputed.
